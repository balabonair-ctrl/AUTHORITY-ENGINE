
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-white border-t border-navy/5">
      <div className="bg-cyan py-20 text-center">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl md:text-6xl font-black text-white mb-8 tracking-tighter uppercase">
            Stop Renting Growth. <br className="hidden md:block"/> Start Owning Authority.
          </h2>
          <a 
            href="https://calendly.com/pocketpublicist-consult"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-block bg-white text-cyan hover:bg-navy hover:text-white px-12 py-6 rounded-full text-2xl font-black shadow-2xl transition-all transform hover:-translate-y-2 active:scale-95"
          >
            BOOK YOUR AUTHORITY AUDIT
          </a>
        </div>
      </div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="flex flex-col md:flex-row justify-between items-center space-y-8 md:space-y-0">
          <div className="flex flex-col items-center md:items-start">
            <div className="text-xl font-black tracking-tighter text-navy mb-4">
              POCKET <span className="text-cyan">PUBLICIST™</span>
            </div>
            <p className="text-navy/40 text-xs font-bold uppercase tracking-widest">
              © {new Date().getFullYear()} Pocket Publicist™. All Rights Reserved.
            </p>
          </div>
          
          <div className="flex space-x-8 text-[10px] font-black uppercase tracking-[0.2em] text-navy/60">
            <a href="#" className="hover:text-cyan transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-cyan transition-colors">Terms of Service</a>
            <a href="mailto:pocketpublicist-consult@gmail.com" className="hover:text-cyan transition-colors">Contact</a>
          </div>

          <div className="flex items-center space-x-3">
            <div className="p-3 bg-navy/5 rounded-full">
              <svg className="w-6 h-6 text-navy/20" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 4.946-2.597 9.29-6.505 11.791a1 1 0 01-1.01 0C6.596 16.29 4 11.945 4 7c0-.68.056-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
            </div>
            <div className="text-[10px] leading-tight font-black uppercase text-navy/30">
              Authorized Infrastructure <br/> Provider for Law Firms
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
