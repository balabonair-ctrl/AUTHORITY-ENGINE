
import React from 'react';

const Pricing: React.FC = () => {
  return (
    <section id="pricing" className="py-24 md:py-32 bg-gray-50 border-y border-navy/5">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-cyan text-sm font-black uppercase tracking-[0.3em] mb-4">Investment</h2>
          <h3 className="text-3xl md:text-5xl font-bold text-navy mb-6">Built For Partnerships, Not Vendors.</h3>
          <p className="text-navy/60 max-w-xl mx-auto font-medium italic">High authority doesn't have to be high friction.</p>
        </div>

        <div className="max-w-xl mx-auto relative">
          <div className="absolute -top-6 left-1/2 -translate-x-1/2 bg-navy text-white px-6 py-2 rounded-full text-xs font-bold uppercase tracking-widest z-10 shadow-lg">
            Complete Authority Engine
          </div>
          <div className="bg-white border-2 border-navy rounded-[2rem] shadow-2xl overflow-hidden transform hover:scale-[1.02] transition-transform">
            <div className="p-10 md:p-14 text-center">
              <div className="flex justify-center items-baseline space-x-1 mb-6">
                <span className="text-4xl font-bold text-navy">$</span>
                <span className="text-7xl font-black text-navy tracking-tight">997</span>
                <span className="text-xl font-bold text-navy/40">/mo</span>
              </div>
              <div className="grid grid-cols-2 gap-4 mb-10">
                <div className="bg-cyan/5 p-4 rounded-xl border border-cyan/10">
                  <p className="text-[10px] font-black uppercase text-cyan tracking-widest mb-1">Setup Fee</p>
                  <p className="text-2xl font-bold text-navy">$0</p>
                </div>
                <div className="bg-navy/5 p-4 rounded-xl border border-navy/10">
                  <p className="text-[10px] font-black uppercase text-navy/60 tracking-widest mb-1">Commitment</p>
                  <p className="text-sm font-bold text-navy uppercase">Month-to-Month</p>
                </div>
              </div>
              <ul className="text-left space-y-4 mb-10 max-w-xs mx-auto">
                <li className="flex items-center font-semibold text-navy">
                  <span className="w-5 h-5 bg-cyan text-white rounded-full flex items-center justify-center text-[10px] mr-3">✓</span>
                  Google 3-Pack Authority
                </li>
                <li className="flex items-center font-semibold text-navy">
                  <span className="w-5 h-5 bg-cyan text-white rounded-full flex items-center justify-center text-[10px] mr-3">✓</span>
                  Review Velocity Management
                </li>
                <li className="flex items-center font-semibold text-navy">
                  <span className="w-5 h-5 bg-cyan text-white rounded-full flex items-center justify-center text-[10px] mr-3">✓</span>
                  Social Trust Integration
                </li>
                <li className="flex items-center font-semibold text-navy">
                  <span className="w-5 h-5 bg-cyan text-white rounded-full flex items-center justify-center text-[10px] mr-3">✓</span>
                  Monthly Strategy Audits
                </li>
              </ul>
              <a 
                href="https://calendly.com/pocketpublicist-consult"
                target="_blank"
                rel="noopener noreferrer"
                className="block w-full bg-navy hover:bg-navy-dark text-white py-6 rounded-2xl text-xl font-bold shadow-xl transition-all transform hover:-translate-y-1 active:scale-95"
              >
                CLAIM YOUR TERRITORY
              </a>
              <p className="mt-6 text-xs text-navy/40 font-bold uppercase tracking-widest">
                Cancel Anytime. Zero Risk.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Pricing;
