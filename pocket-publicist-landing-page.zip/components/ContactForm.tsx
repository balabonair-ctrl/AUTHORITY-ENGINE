
import React, { useState } from 'react';

const ContactForm: React.FC = () => {
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    // Simulate API call
    setTimeout(() => setSubmitted(false), 5000);
  };

  return (
    <section id="contact" className="py-24 md:py-32 bg-navy relative overflow-hidden">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="bg-white rounded-3xl shadow-2xl overflow-hidden flex flex-col md:flex-row">
          <div className="bg-cyan p-10 md:p-14 text-white md:w-1/3 flex flex-col justify-center">
            <h3 className="text-3xl font-black mb-6 leading-tight uppercase tracking-tighter">Secure Your Market Audit.</h3>
            <p className="text-white/80 font-medium text-sm leading-relaxed mb-8">
              Prefer a direct message? Submit your details and our growth partner will contact your firm within 24 hours.
            </p>
            <div className="space-y-4 text-xs font-bold uppercase tracking-widest opacity-80">
              <p className="flex items-center">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" /><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" /></svg>
                National Reach
              </p>
              <p className="flex items-center">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 5a2 2 0 012-2h3.28a1 1 0 01.948.684l1.498 4.493a1 1 0 01-.502 1.21l-2.257 1.13a11.042 11.042 0 005.516 5.516l1.13-2.257a1 1 0 011.21-.502l4.493 1.498a1 1 0 01.684.949V19a2 2 0 01-2 2h-1C9.716 21 3 14.284 3 6V5z" /></svg>
                504-531-3541
              </p>
              <p className="flex items-center">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
                pocketpublicist-consult@gmail.com
              </p>
            </div>
          </div>
          
          <div className="p-10 md:p-14 md:w-2/3">
            {submitted ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-4">
                <div className="w-16 h-16 bg-cyan/10 text-cyan rounded-full flex items-center justify-center text-3xl">✓</div>
                <h4 className="text-2xl font-bold text-navy">Audit Requested.</h4>
                <p className="text-navy/60">A consultant will reach out shortly. <br/> Your territory is being analyzed.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-navy/40 mb-2">Full Name</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g. Robert Shapiro"
                      className="w-full bg-gray-50 border border-navy/10 px-5 py-4 rounded-xl focus:ring-2 focus:ring-cyan/20 focus:border-cyan outline-none transition-all duration-300 font-semibold"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-black uppercase tracking-widest text-navy/40 mb-2">Law Firm Name</label>
                    <input 
                      required
                      type="text" 
                      placeholder="e.g. Shapiro & Associates"
                      className="w-full bg-gray-50 border border-navy/10 px-5 py-4 rounded-xl focus:ring-2 focus:ring-cyan/20 focus:border-cyan outline-none transition-all duration-300 font-semibold"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-[10px] font-black uppercase tracking-widest text-navy/40 mb-2">Email Address</label>
                  <input 
                    required
                    type="email" 
                    placeholder="robert@firm.com"
                    className="w-full bg-gray-50 border border-navy/10 px-5 py-4 rounded-xl focus:ring-2 focus:ring-cyan/20 focus:border-cyan outline-none transition-all duration-300 font-semibold"
                  />
                </div>
                <button 
                  type="submit"
                  className="w-full bg-navy hover:bg-navy-dark text-white py-5 rounded-xl text-lg font-bold shadow-lg transition-all transform hover:-translate-y-1 active:scale-95"
                >
                  SEND AUDIT REQUEST
                </button>
                <p className="text-center text-[10px] text-navy/30 font-bold uppercase tracking-widest">
                  Secure & Confidential Transmission
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

export default ContactForm;
