
import React from 'react';

const AuthorityEngine: React.FC = () => {
  const cards = [
    {
      title: "Google Business Authority",
      desc: "Deep optimization of your primary GMB profiles for the Local 3-Pack. We engineer your profile for maximum signal strength and map dominance.",
      details: ["Weekly Strategic Posts", "Photo Optimization", "Q&A Management"]
    },
    {
      title: "AI Search & SEO Optimization",
      desc: "Future-proof your firm for the next era of search. We optimize your data for AI-driven results, LLM citations, and traditional organic ranking.",
      details: ["AI Search Optimization", "AI SEO Data Structuring", "Core SEO Optimization"]
    },
    {
      title: "Review Velocity System",
      desc: "Our automated system ensures a steady heartbeat of fresh, authoritative reviews from verified clients to maintain trust and relevance.",
      details: ["Automated SMS/Email", "Negative Review Shielding", "Sentiment Analysis"]
    },
    {
      title: "Legal Directory Management",
      desc: "Active management of your presence across high-authority legal directories to capture referral traffic and boost domain authority.",
      details: ["Directory Syncing", "Backlink Authority", "Profile Optimization"]
    },
    {
      title: "Market Expansion Suite",
      desc: "Dominate surrounding territories using our proven blueprint for expanding your digital footprint without the need for massive overhead.",
      details: ["Google Satellite Office Checklist", "Proximity Optimization", "Multi-Location Scaling"]
    },
    {
      title: "Trust & Performance Audits",
      desc: "Transparent reporting on the metrics that actually matter for your intake desk. We track authority, visibility, and conversion—not just clicks.",
      details: ["Facebook Trust Guard", "Heatmap Visibility Tracking", "Monthly Strategy Audits"]
    }
  ];

  return (
    <section id="engine" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-24">
          <div>
            <span className="text-cyan font-bold uppercase tracking-widest text-xs mb-4 block">The Solution</span>
            <h2 className="text-4xl md:text-5xl font-extrabold text-navy mb-6 tracking-tight">
              Meet the Local Authority Engine™
            </h2>
            <p className="text-navy/70 text-lg leading-relaxed mb-8">
              We build "Authority Infrastructure". Instead of renting traffic from Google Ads, we help you 
              <strong> own the market </strong> by positioning your firm as the inevitable choice for personal injury victims in your region.
            </p>
            <div className="flex space-x-4 items-center">
              <div className="h-px flex-1 bg-navy/10"></div>
              <span className="text-navy/40 font-bold uppercase text-[10px] tracking-widest italic">Comprehensive Infrastructure</span>
              <div className="h-px flex-1 bg-navy/10"></div>
            </div>
          </div>
          <div className="relative">
            <div className="absolute inset-0 bg-cyan/10 rounded-3xl -rotate-2 -z-10"></div>
            <div className="bg-navy p-8 md:p-12 rounded-3xl shadow-2xl text-white">
              <blockquote className="text-2xl font-medium italic border-l-4 border-cyan pl-6 mb-6">
                "Rankings are a byproduct of authority. We stop chasing algorithms and start dominating markets."
              </blockquote>
              <div className="flex items-center space-x-4">
                <div className="w-12 h-12 rounded-full bg-cyan/20 flex items-center justify-center font-bold text-cyan">PP</div>
                <div>
                  <p className="font-bold">Pocket Publicist™ Methodology</p>
                  <p className="text-xs text-white/50">Infrastructure Over Interruption</p>
                </div>
              </div>
            </div>
          </div>uh
        </div>
uh
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {cards.map((card, idx) => (
            <div key={idx} className="bg-white border border-navy/10 p-8 rounded-3xl shadow-sm hover:shadow-2xl hover:-translate-y-2 hover:border-cyan/30 transition-all duration-300 group flex flex-col justify-between cursor-default">
              <div>
                <h4 className="text-xl font-bold text-navy mb-4 group-hover:text-cyan transition-colors">{card.title}</h4>
                <p className="text-navy/60 text-sm mb-6 leading-relaxed">{card.desc}</p>
              </div>
              <ul className="space-y-3">
                {card.details.map((detail, dIdx) => (
                  <li key={dIdx} className="flex items-center text-xs font-semibold text-navy/80">
                    <svg className="w-4 h-4 text-cyan mr-2 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="3" d="M5 13l4 4L19 7"></path>
                    </svg>
                    {detail}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default AuthorityEngine;
