
import React, { useState } from 'react';

const FAQItem: React.FC<{ q: string, a: string }> = ({ q, a }) => {
  const [isOpen, setIsOpen] = useState(false);
  return (
    <div className="border-b border-navy/10">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full py-6 flex justify-between items-center text-left group"
      >
        <span className="text-lg md:text-xl font-bold text-navy group-hover:text-cyan transition-colors">{q}</span>
        <span className={`text-2xl text-cyan transition-transform ${isOpen ? 'rotate-45' : ''}`}>+</span>
      </button>
      <div className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-96 pb-6' : 'max-h-0'}`}>
        <p className="text-navy/60 leading-relaxed font-medium">{a}</p>
      </div>
    </div>
  );
};

const FAQ: React.FC = () => {
  const items = [
    {
      q: "How fast will I see results?",
      a: "You'll see incremental progress in profile activity signals within 14 days. Our full Authority Engine typically takes 90 days to fully stabilize your market dominance and drive consistent intake."
    },
    {
      q: "Do you guarantee #1 rankings?",
      a: "Ethics matter in law. No honest agency can guarantee #1 rankings because they don't own Google. We guarantee the signals: the velocity, the authority, and the trust. Rankings are the inevitable byproduct of that work."
    },
    {
      q: "Is this compliant with state bar ethics?",
      a: "Yes. We operate as a publicist and technical infrastructure partner. We do not participate in fee-splitting, 'buying' reviews, or any black-hat tactics that would jeopardize your license."
    },
    {
      q: "What do I need to get started?",
      a: "You need a verified Google Business Profile and a commitment to handling the increased case flow professionally. We handle the rest."
    }
  ];

  return (
    <section id="faq" className="py-24 md:py-32 bg-white">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-extrabold text-navy tracking-tight">Frequently Asked Questions</h2>
        </div>
        <div className="space-y-2">
          {items.map((item, idx) => <FAQItem key={idx} {...item} />)}
        </div>
      </div>
    </section>
  );
};

export default FAQ;
