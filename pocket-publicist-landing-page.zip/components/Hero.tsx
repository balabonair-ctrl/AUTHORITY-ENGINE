
import React from 'react';

const Hero: React.FC = () => {
  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden hero-pattern">
      {/* Decorative gradients */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-cyan/5 rounded-full blur-3xl -z-10"></div>
      <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-navy/5 rounded-full blur-3xl -z-10"></div>
      
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center space-x-2 bg-navy/5 px-4 py-2 rounded-full mb-8">
          <svg className="w-4 h-4 text-cyan" fill="currentColor" viewBox="0 0 20 20">
            <path fillRule="evenodd" d="M2.166 4.999A11.954 11.954 0 0010 1.944 11.954 11.954 0 0017.834 5c.11.65.166 1.32.166 2.001 0 4.946-2.597 9.29-6.505 11.791a1 1 0 01-1.01 0C6.596 16.29 4 11.945 4 7c0-.68.056-1.35.166-2.001zm11.541 3.708a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
          </svg>
          <span className="text-[10px] sm:text-xs font-bold uppercase tracking-[0.2em] text-navy/70">
            Exclusive to Personal Injury Law Firms
          </span>
        </div>

        <h1 className="text-4xl md:text-6xl lg:text-7xl font-extrabold text-navy leading-[1.1] tracking-tight mb-8">
          Turn Your Google Profile Into a <br className="hidden md:block" />
          <span className="text-transparent bg-clip-text bg-gradient-to-r from-navy via-cyan to-navy">
            24/7 Case Intake Asset.
          </span>
        </h1>
        
        <p className="max-w-2xl mx-auto text-lg md:text-xl text-navy/70 mb-10 leading-relaxed font-medium">
          No ads. No lead vendors. No long-term contracts. <br className="hidden sm:inline" />
          Own your market by building the infrastructure of local authority.
        </p>

        <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-4">
          <a 
            href="https://calendly.com/pocketpublicist-consult"
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto bg-cyan hover:bg-cyan-dark text-white px-10 py-5 rounded-full text-lg font-bold shadow-xl shadow-cyan/20 transition-all transform hover:-translate-y-1 active:scale-95"
          >
            BOOK A FREE AUTHORITY AUDIT
          </a>
          <p className="text-xs text-navy/50 font-semibold uppercase tracking-widest italic">
            Limited Monthly Capacity
          </p>
        </div>

        {/* Replaced image container with a stylized feature board */}
        <div className="mt-16 relative mx-auto max-w-4xl">
          <div className="absolute -inset-1 bg-gradient-to-r from-cyan/20 to-navy/10 rounded-2xl blur"></div>
          <div className="relative bg-white p-8 md:p-12 rounded-xl shadow-2xl border border-navy/5 text-left">
             <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                <div className="space-y-3">
                   <div className="h-2 w-12 bg-cyan rounded-full"></div>
                   <h4 className="text-sm font-black text-navy uppercase tracking-widest">Visibility</h4>
                   <p className="text-xs text-navy/60 leading-relaxed">Aggressive local optimization to ensure your firm appears exactly where claimants are searching.</p>
                </div>
                <div className="space-y-3">
                   <div className="h-2 w-12 bg-navy rounded-full"></div>
                   <h4 className="text-sm font-black text-navy uppercase tracking-widest">Authority</h4>
                   <p className="text-xs text-navy/60 leading-relaxed">Systematic trust-signal generation that positions you as the definitive expert in your market.</p>
                </div>
                <div className="space-y-3">
                   <div className="h-2 w-12 bg-cyan rounded-full"></div>
                   <h4 className="text-sm font-black text-navy uppercase tracking-widest">Conversion</h4>
                   <p className="text-xs text-navy/60 leading-relaxed">Optimized intake workflows that turn casual profile viewers into signed personal injury cases.</p>
                </div>
             </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
