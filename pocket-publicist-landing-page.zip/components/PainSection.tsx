
import React from 'react';

const PainSection: React.FC = () => {
  const leaks = [
    {
      title: "Stagnant Review Velocity",
      desc: "If you aren't adding fresh, 5-star validation every week, you are invisible to high-intent claimants.",
      icon: (
        <svg className="w-8 h-8 text-cyan" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6" />
        </svg>
      )
    },
    {
      title: "Dead Profile Activity",
      desc: "Google prioritizes 'living' profiles. Dormant profiles are pushed to page 2, where cases go to die.",
      icon: (
        <svg className="w-8 h-8 text-cyan" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 5.636l-3.536 3.536m0 5.656l3.536 3.536M9.172 9.172L5.636 5.636m3.536 14.828l3.536-3.536M9.172 14.828l-3.536 3.536M12 3v4m0 10v4M3 12h4m10 0h4" />
        </svg>
      )
    },
    {
      title: "Thin Trust Signals",
      desc: "Potential clients verify you on Facebook and Google before calling. If they see nothing, they call your competitor.",
      icon: (
        <svg className="w-8 h-8 text-cyan" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
        </svg>
      )
    },
    {
      title: "Conversion Killers",
      desc: "Unanswered reviews and lack of local context signal a 'factory' firm that doesn't care. You're losing signed cases.",
      icon: (
        <svg className="w-8 h-8 text-cyan" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M18.364 18.364A9 9 0 005.636 5.636m12.728 12.728A9 9 0 015.636 5.636m12.728 12.728L5.636 5.636" />
        </svg>
      )
    }
  ];

  return (
    <section id="problems" className="bg-navy py-24 md:py-32 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-cyan text-sm font-black uppercase tracking-[0.3em] mb-4">The Silent Revenue Bleed</h2>
          <h3 className="text-3xl md:text-5xl font-bold text-white mb-6">
            THE INVISIBLE PROBLEM <br className="hidden md:block" /> COSTING YOU SIGNED CASES.
          </h3>
          <p className="text-white/60 max-w-2xl mx-auto text-lg leading-relaxed">
            Most firms think they have a "leads" problem. You actually have an "Authority" problem. Every day, 
            high-value cases see your profile and decide to call someone else.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {leaks.map((leak, idx) => (
            <div key={idx} className="bg-navy-light/40 border border-white/5 p-8 rounded-2xl hover:border-cyan/30 transition-all group">
              <div className="mb-6 group-hover:scale-110 transition-transform duration-300 inline-block">
                {leak.icon}
              </div>
              <h4 className="text-xl font-bold text-white mb-3 tracking-tight">{leak.title}</h4>
              <p className="text-white/50 text-sm leading-relaxed">{leak.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default PainSection;
