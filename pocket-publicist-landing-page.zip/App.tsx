
import React, { useEffect } from 'react';
import AOS from 'aos';
import Navigation from './components/Navigation';
import Hero from './components/Hero';
import PainSection from './components/PainSection';
import AuthorityEngine from './components/AuthorityEngine';
import Pricing from './components/Pricing';
import FAQ from './components/FAQ';
import ContactForm from './components/ContactForm';
import Footer from './components/Footer';

const App: React.FC = () => {
  useEffect(() => {
    // Initialize AOS with professional, subtle settings
    AOS.init({
      duration: 800,
      easing: 'ease-out-quad',
      once: true,
      offset: 120,
      delay: 50,
    });
  }, []);

  return (
    <div className="min-h-screen">
      <Navigation />
      <main>
        <div data-aos="fade-in">
          <Hero />
        </div>
        
        <div data-aos="fade-up">
          <PainSection />
        </div>
        
        <div data-aos="fade-up">
          <AuthorityEngine />
        </div>
        
        <div data-aos="fade-up">
          <Pricing />
        </div>
        
        <div data-aos="fade-up">
          <FAQ />
        </div>
        
        <div data-aos="fade-up">
          <ContactForm />
        </div>
      </main>
      <Footer />
      
      {/* Sticky Mobile CTA */}
      <div className="md:hidden fixed bottom-6 left-1/2 -translate-x-1/2 z-40 w-[90%]">
        <a 
          href="https://calendly.com/pocketpublicist-consult"
          target="_blank"
          rel="noopener noreferrer"
          className="block w-full bg-cyan text-white text-center py-4 rounded-2xl font-black text-sm uppercase tracking-widest shadow-2xl active:scale-95 transition-transform"
        >
          Book Authority Audit
        </a>
      </div>
    </div>
  );
};

export default App;
